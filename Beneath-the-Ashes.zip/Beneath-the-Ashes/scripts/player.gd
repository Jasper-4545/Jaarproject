extends CharacterBody2D

signal changed
signal defeated

const SPEED := 210.0
const JUMP := -380.0
const GRAVITY := 1050.0
const MAX_HEALTH := 5
const MAX_FOCUS := 5
const JUMP_SOUND := preload("res://assets/sounds/jump.wav")
const HURT_SOUND := preload("res://assets/sounds/hurt.wav")
const HEAL_SOUND := preload("res://assets/sounds/power_up.wav")

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var camera: Camera2D = $Camera2D
var health := MAX_HEALTH
var focus := 0
var fragments := 0
var dash_unlocked := false
var facing := 1.0
var coyote := 0.0
var jump_buffer := 0.0
var dash_time := 0.0
var dash_spent := false
var attack_time := 0.0
var invulnerable := 0.0
var heal_time := 0.0
var struck: Array[Node] = []
var speaker := AudioStreamPlayer.new()


func _ready() -> void:
	add_child(speaker)
	speaker.volume_db = -13


func _physics_process(delta: float) -> void:
	if health <= 0:
		return
	var grounded := is_on_floor()
	coyote = 0.10 if grounded else maxf(0.0, coyote - delta)
	jump_buffer = maxf(0.0, jump_buffer - delta)
	attack_time = maxf(0.0, attack_time - delta)
	invulnerable = maxf(0.0, invulnerable - delta)
	if grounded and dash_time <= 0.0:
		dash_spent = false
	if Input.is_action_just_pressed("jump"):
		jump_buffer = 0.12
	var direction := Input.get_axis("left", "right")
	if direction != 0.0 and attack_time <= 0.0 and dash_time <= 0.0:
		facing = direction
	if dash_unlocked and not dash_spent and Input.is_action_just_pressed("dash"):
		dash_time = 0.17
		dash_spent = true
		heal_time = 0.0
	if Input.is_action_just_pressed("attack") and attack_time <= 0.0:
		attack_time = 0.26
		struck.clear()
		sprite.play("attack")
	# The dash suspends gravity and ends on contact with a wall.
	if dash_time > 0.0:
		dash_time = maxf(0.0, dash_time - delta)
		velocity = Vector2(facing * 520.0, 0.0)
	else:
		velocity.x = move_toward(velocity.x, direction * SPEED, delta * 2000.0)
		if not grounded:
			velocity.y += GRAVITY * (1.25 if velocity.y > 0.0 else 1.0) * delta
		if coyote > 0.0 and jump_buffer > 0.0:
			velocity.y = JUMP
			coyote = 0.0
			jump_buffer = 0.0
			play_sound(JUMP_SOUND)
		if Input.is_action_just_released("jump") and velocity.y < -120.0:
			velocity.y *= 0.48
	advance_heal(delta, direction)
	move_and_slide()
	if is_on_wall():
		dash_time = 0.0
	if attack_time > 0.08:
		apply_attack(Input.is_action_pressed("up"), Input.is_action_pressed("down") and not is_on_floor())
	update_animation(direction)
	queue_redraw()


func advance_heal(delta: float, direction: float) -> void:
	if is_on_floor() and Input.is_action_pressed("heal") and direction == 0.0 and focus >= 3 and health < MAX_HEALTH and dash_time <= 0.0 and attack_time <= 0.0 and velocity.y >= 0.0:
		heal_time += delta
		if heal_time >= 0.62:
			heal_time = 0.0
			focus -= 3
			health += 1
			play_sound(HEAL_SOUND)
			changed.emit()
	else:
		heal_time = 0.0


func apply_attack(up: bool, down: bool) -> void:
	var origin := global_position + Vector2(0, -20)
	for target in get_tree().get_nodes_in_group("enemy"):
		if target in struck or not target.is_alive():
			continue
		var offset: Vector2 = target.hit_center() - origin
		var distance: float = target.hit_radius()
		var horizontal := offset.x * facing > -distance * 0.5 and offset.x * facing < 61.0 + distance and absf(offset.y) < 25.0 + distance
		var vertical := absf(offset.x) < 27.0 + distance and absf(offset.y) < 67.0 + distance and offset.y * (-1.0 if up else 1.0) > -distance * 0.5
		if (vertical if up or down else horizontal):
			struck.append(target)
			target.take_hit(facing)
			focus = mini(MAX_FOCUS, focus + 1)
			if down:
				velocity.y = -305.0
				dash_spent = false
			changed.emit()


func update_animation(direction: float) -> void:
	sprite.flip_h = facing < 0
	sprite.modulate.a = 0.35 if invulnerable > 0.0 and int(invulnerable * 20) % 2 == 0 else 1.0
	sprite.modulate.g = 0.90 if dash_time > 0.0 else 1.0
	if attack_time > 0.0:
		return
	if not is_on_floor():
		sprite.play("jump")
	elif direction != 0.0:
		sprite.play("run")
	else:
		sprite.play("idle")


func hurt(source: Vector2, force: bool = false) -> bool:
	if health <= 0 or (not force and (invulnerable > 0.0 or dash_time > 0.0)):
		return false
	health -= 1
	dash_time = 0.0
	heal_time = 0.0
	invulnerable = 0.88
	velocity = Vector2(signf(global_position.x - source.x) * 260.0, -225.0)
	play_sound(HURT_SOUND)
	changed.emit()
	if health == 0:
		defeated.emit()
	return true


func respawn(where: Vector2, refill: bool) -> void:
	global_position = where
	velocity = Vector2.ZERO
	dash_time = 0.0
	dash_spent = false
	coyote = 0.0
	jump_buffer = 0.0
	attack_time = 0.0
	heal_time = 0.0
	struck.clear()
	invulnerable = 0.7
	if refill:
		health = MAX_HEALTH
		focus = 0
	camera.reset_smoothing()
	changed.emit()


func play_sound(stream: AudioStream) -> void:
	speaker.stream = stream
	speaker.play()


func _draw() -> void:
	if attack_time > 0.08:
		var angle := 0.0 if facing > 0 else PI
		if Input.is_action_pressed("up"):
			angle = -PI / 2
		elif Input.is_action_pressed("down") and not is_on_floor():
			angle = PI / 2
		draw_arc(Vector2(0, -20), 49, angle - 0.85, angle + 0.85, 20, Color("#aef9ee"), 3.0, true)
	if dash_time > 0.0:
		draw_line(Vector2(-facing * 57, -19), Vector2(-facing * 14, -19), Color("#65d6e0"), 2.0, true)
	if heal_time > 0.0:
		draw_arc(Vector2(0, -20), 26, -PI / 2, -PI / 2 + TAU * heal_time / 0.62, 24, Color("#ffe6a8"), 2.0, true)
