extends Node2D

const SLIME := preload("res://assets/sprites/slime_purple.png")
const GUARDIAN := preload("res://assets/sprites/ash_warden_frames.png")

var hero
var boss := false
var hp := 3
var maximum_hp := 3
var home := Vector2.ZERO
var facing := -1.0
var timer := 0.0
var animation_time := 0.0
var animation := "idle"
var flash := 0.0
var state := "idle"
var phase_time := 0.8
var struck := false
var active := false
var min_x := 0.0
var max_x := 0.0


func configure(player, start: Vector2, left: float, right: float, guardian: bool) -> void:
	hero = player
	position = start
	home = start
	min_x = left
	max_x = right
	boss = guardian
	maximum_hp = 9 if boss else 3
	hp = maximum_hp
	add_to_group("enemy")
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


func reset() -> void:
	position = home
	hp = maximum_hp
	state = "idle"
	animation = "idle"
	animation_time = 0.0
	phase_time = 0.8
	flash = 0.0
	facing = -1.0
	active = false
	visible = true


func is_alive() -> bool:
	return hp > 0


func hit_center() -> Vector2:
	return global_position + Vector2(0, -32 if boss else -13)


func hit_radius() -> float:
	return 25.0 if boss else 11.0


func take_hit(direction: float) -> void:
	if hp <= 0:
		return
	hp -= 1
	flash = 0.14
	if boss:
		active = true
	else:
		position.x = clampf(position.x + direction * 12.0, min_x, max_x)
		if hp == 0:
			visible = false


func _physics_process(delta: float) -> void:
	timer += delta
	update_boss_animation(delta)
	flash = maxf(0.0, flash - delta)
	queue_redraw()
	if hp <= 0 or hero.health <= 0:
		return
	var gap: Vector2 = hero.global_position - global_position
	if boss and absf(gap.x) < 235.0:
		active = true
	if boss and not active:
		return
	phase_time -= delta
	match state:
		"idle":
			if absf(gap.x) < (205.0 if boss else 86.0) and absf(gap.y) < 70.0 and phase_time <= 0.0:
				facing = 1.0 if gap.x >= 0 else -1.0
				state = "warning"
				phase_time = 0.48 if boss and hp <= 4 else 0.64
			elif not boss:
				position.x += facing * 39.0 * delta
				if position.x < min_x or position.x > max_x:
					facing *= -1
		"warning":
			if phase_time <= 0.0:
				state = "lunge"
				phase_time = 0.42 if boss else 0.32
				struck = false
		"lunge":
			position.x += facing * (350.0 if boss else 135.0) * delta
			if phase_time <= 0.0:
				state = "recover"
				phase_time = 0.55 if boss else 0.77
		"recover":
			if phase_time <= 0.0:
				state = "idle"
	position.x = clampf(position.x, min_x, max_x)
	var collision_range := 34.0 if boss else 22.0
	if state == "lunge":
		collision_range += 10.0
	if not struck and absf(hero.global_position.x - position.x) < collision_range and absf(hero.global_position.y - position.y) < (48.0 if boss else 25.0):
		struck = hero.hurt(global_position) if state == "lunge" else false
		if state != "lunge":
			hero.hurt(global_position)


func update_boss_animation(delta: float) -> void:
	if not boss:
		return
	var next := state
	if hp <= 0:
		next = "defeated"
	elif flash > 0.0 and state != "lunge":
		next = "hurt"
	if next != animation:
		animation = next
		animation_time = 0.0
	else:
		animation_time += delta


func boss_frame() -> Rect2:
	var row := 0
	var frame := int(animation_time * 6.0) % 4
	match animation:
		"warning":
			row = 1
			frame = mini(3, int(animation_time * 10.0))
		"lunge":
			row = 2
			frame = mini(3, int(animation_time * 15.0))
		"recover":
			row = 3
			frame = mini(3, int(animation_time * 8.0))
		"hurt":
			row = 4
			frame = mini(3, int(animation_time * 28.0))
		"defeated":
			row = 5
			frame = mini(3, int(animation_time * 8.0))
	return Rect2(frame * 72, row * 64, 72, 64)


func _draw() -> void:
	if hp <= 0 and (not boss or animation_time > 0.85):
		return
	var tint := Color.WHITE
	if hp > 0 and state == "warning":
		tint = Color("#ff9578") if int(timer * 16) % 2 == 0 else Color("#ffd6a6")
	elif flash > 0:
		tint = Color("#ff7775")
	var art: Texture2D = GUARDIAN if boss else SLIME
	var index := int(timer * 8) % 4
	if state == "warning":
		index = 1
	elif state == "lunge":
		index = 4 + int(timer * 16) % 4
	elif state == "recover":
		index = 8 + int(timer * 8) % 4
	var source := boss_frame() if boss else Rect2(index % 4 * 24, int(index / 4.0) * 24, 24, 24)
	var size := 41.0
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(-facing if boss else facing, 1))
	var destination := Rect2(-65, -108, 130, 115) if boss else Rect2(-size / 2.0, -size, size, size)
	draw_texture_rect_region(art, destination, source, tint)
	draw_set_transform(Vector2.ZERO)
	if hp <= 0:
		return
	if state == "warning":
		var center := Vector2(0, -102 if boss else -34)
		draw_rect(Rect2(center + Vector2(-1, -10), Vector2(3, 7)), Color("#ffcd93"))
		draw_rect(Rect2(center, Vector2(2, 2)), Color("#ffcd93"))
	if boss and state == "lunge":
		var angle := 0.0 if facing > 0 else PI
		draw_arc(Vector2(5.0 * facing, -38), 51, angle - 0.88, angle + 0.88, 14, Color("#fdb98c"), 2.0)
	if state == "lunge":
		for line in range(3):
			var end := Vector2(-facing * ((38.0 if boss else size / 2.0) + 12), -14 - line * 9)
			draw_line(end, end + Vector2(-facing * (16 + line * 3), 0), Color("#e78076"), 2)
