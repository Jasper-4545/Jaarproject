extends VBoxContainer

signal closed
signal display_changed(canvas_size: Vector2i, render_size: Vector2i)
signal sound_changed(music_level: float, effects_level: float)

const FILE := "user://settings.cfg"
const ASPECT := Vector2i(16, 9)
const DEFAULT_SIZE := Vector2i(1024, 576)
const RESOLUTION_HEIGHTS := [360, 480, 600, 720, 768, 800, 900, 960, 1080, 1200, 1440, 1600, 1800, 2160, 2880, 4320]
const CONTROLS := {
	"left": ["Move Left", KEY_A, KEY_Q, KEY_LEFT],
	"right": ["Move Right", KEY_D, KEY_RIGHT],
	"jump": ["Jump", KEY_SPACE],
	"up": ["Aim Up", KEY_W, KEY_Z, KEY_UP],
	"down": ["Aim Down", KEY_S, KEY_DOWN],
	"attack": ["Attack", KEY_J, KEY_X],
	"dash": ["Ashstep", KEY_K, KEY_SHIFT],
	"heal": ["Heal", KEY_F],
	"interact": ["Interact", KEY_E],
}

var config := ConfigFile.new()
var music_level := 1.0
var effects_level := 1.0
var waiting := ""
var key_buttons: Dictionary = {}
var resolutions: Array[Vector2i] = []


@onready var feedback: Label = %Feedback
@onready var resolution_selector: OptionButton = %Resolution
@onready var back: Button = %Back
@onready var sliders: Array[HSlider] = [%MusicVolume, %EffectsVolume]


func _ready() -> void:
	load_preferences()
	for action: String in CONTROLS:
		var button: Button = %KeyBindings.get_node(action)
		button.text = key_list(action)
		button.pressed.connect(capture.bind(action))
		key_buttons[action] = button
	sliders[0].set_value_no_signal(roundf(music_level * 100))
	sliders[1].set_value_no_signal(roundf(effects_level * 100))
	%MusicPercent.text = "%d%%" % sliders[0].value
	%EffectsPercent.text = "%d%%" % sliders[1].value
	sliders[0].value_changed.connect(update_volume.bind(true, %MusicPercent))
	sliders[1].value_changed.connect(update_volume.bind(false, %EffectsPercent))
	resolution_selector.item_selected.connect(change_resolution)
	resolution_selector.get_popup().about_to_popup.connect(refresh_display_on_open)
	visibility_changed.connect(refresh_display_on_open)
	%Defaults.pressed.connect(restore_defaults)
	back.pressed.connect(close)
	apply_display.call_deferred(get_window())


func load_preferences() -> void:
	# The English project name changes Godot's default user data folder.
	if config.load(FILE) == ERR_FILE_NOT_FOUND:
		var legacy_file := OS.get_user_data_dir().get_base_dir().path_join("Onder de As/settings.cfg")
		if config.load(legacy_file) == OK:
			config.save(FILE)
	for action: String in CONTROLS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		var saved_key := int(config.get_value("controls", action, 0))
		bind_keys(action, [saved_key] if saved_key > 0 else CONTROLS[action].slice(1))
	music_level = clampf(float(config.get_value("sound", "music", 1.0)), 0.0, 1.0)
	effects_level = clampf(float(config.get_value("sound", "effects", 1.0)), 0.0, 1.0)


func update_volume(value: float, is_music: bool, percent: Label) -> void:
	percent.text = "%d%%" % value
	if is_music:
		music_level = value / 100.0
		config.set_value("sound", "music", music_level)
	else:
		effects_level = value / 100.0
		config.set_value("sound", "effects", effects_level)
	sound_changed.emit(music_level, effects_level)
	save()


func change_resolution(index: int) -> void:
	if index < 0 or index >= resolutions.size():
		return
	var window := get_window()
	var size := resolutions[index]
	if not fits(size, window_limit(window)):
		apply_display(window)
		return
	config.set_value("display", "resolution", size)
	apply_display(window)
	feedback.text = "Resolution set to %d × %d." % [size.x, size.y]
	save()


func refresh_display_on_open() -> void:
	if is_visible_in_tree():
		apply_display(get_window())


func apply_display(window: Window) -> void:
	var target := refresh_resolutions(window)
	# An editor-hosted window can keep its outer size while the game renders at target.
	window.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT
	window.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP
	window.content_scale_size = target
	display_changed.emit(DEFAULT_SIZE, target)
	if window.mode == Window.MODE_WINDOWED and can_manage_window() and window.size != target:
		var usable := DisplayServer.screen_get_usable_rect(window.current_screen)
		window.size = target
		window.position = usable.position + (usable.size - window.size) / 2


func can_manage_window() -> bool:
	return DisplayServer.get_name() != "headless" and not Engine.is_embedded_in_editor()


func refresh_resolutions(window: Window) -> Vector2i:
	var limit := window_limit(window)
	var choices := resolution_choices(limit)
	var list_changed := choices != resolutions
	resolutions = choices
	var target := preferred_resolution(limit, choices)
	if is_instance_valid(resolution_selector):
		if list_changed or resolution_selector.item_count == 0:
			resolution_selector.clear()
			for size in resolutions:
				resolution_selector.add_item("%d × %d" % [size.x, size.y])
		resolution_selector.select(resolutions.find(target))
	return target


func preferred_resolution(limit: Vector2i, choices: Array[Vector2i]) -> Vector2i:
	# Keep older 16:9 resolution preferences while ignoring old display modes.
	var legacy: Vector2i = config.get_value("display", "resolution_0", DEFAULT_SIZE)
	if not fits(legacy, limit):
		legacy = config.get_value("display", "window_resolution_0", legacy)
	var preferred: Vector2i = config.get_value("display", "resolution", legacy)
	var target := choices[0]
	for candidate in choices:
		if not fits(candidate, preferred):
			break
		target = candidate
	return target


func window_limit(window: Window) -> Vector2i:
	if DisplayServer.get_name() == "headless":
		return Vector2i(1920, 1200)
	var screen := window.current_screen
	var screen_size := DisplayServer.screen_get_size(screen)
	var usable := DisplayServer.screen_get_usable_rect(screen).size
	var decorations := (window.get_size_with_decorations() - window.size).max(Vector2i.ZERO)
	return screen_size.min(usable - decorations).max(Vector2i.ONE)


func resolution_choices(limit: Vector2i) -> Array[Vector2i]:
	var maximum := mini(floori(float(limit.x) / ASPECT.x), floori(float(limit.y) / ASPECT.y))
	var choices: Array[Vector2i] = []
	for height in RESOLUTION_HEIGHTS:
		var candidate := ASPECT * floori(float(height) / ASPECT.y)
		if fits(candidate, limit) and candidate not in choices:
			choices.append(candidate)
	if fits(DEFAULT_SIZE, limit) and DEFAULT_SIZE not in choices:
		choices.append(DEFAULT_SIZE)
	var largest := ASPECT * maximum if maximum > 0 else limit
	if fits(largest, limit) and largest not in choices:
		choices.append(largest)
	choices.sort_custom(func(left: Vector2i, right: Vector2i): return left.x < right.x)
	return choices


func fits(size: Vector2i, limit: Vector2i) -> bool:
	return size.x > 0 and size.y > 0 and size.x <= limit.x and size.y <= limit.y


func bind_keys(action: String, keys: Array) -> void:
	InputMap.action_erase_events(action)
	for code: int in keys:
		var key := InputEventKey.new()
		key.keycode = code
		InputMap.action_add_event(action, key)


func key_list(action: String) -> String:
	var labels := PackedStringArray()
	for event: InputEventKey in InputMap.action_get_events(action):
		labels.append(OS.get_keycode_string(event.keycode))
	return " / ".join(labels)


func capture(action: String) -> void:
	cancel_capture()
	waiting = action
	key_buttons[action].text = "Press a key"
	feedback.text = "Press an unused key, or Esc to cancel."


func cancel_capture() -> void:
	if not waiting.is_empty():
		key_buttons[waiting].text = key_list(waiting)
	waiting = ""


func _input(event: InputEvent) -> void:
	if not visible or not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE:
		get_viewport().set_input_as_handled()
		if waiting.is_empty():
			close()
		else:
			cancel_capture()
			feedback.text = "Key change canceled."
		return
	if waiting.is_empty() or event.keycode == 0:
		return
	get_viewport().set_input_as_handled()
	if event.keycode == KEY_TAB:
		feedback.text = "Tab is reserved for menu navigation."
		return
	for action: String in CONTROLS:
		if action != waiting and InputMap.action_has_event(action, event):
			feedback.text = "Key already assigned to %s." % CONTROLS[action][0]
			return
	bind_keys(waiting, [event.keycode])
	config.set_value("controls", waiting, event.keycode)
	cancel_capture()
	feedback.text = "Key updated."
	save()


func close() -> void:
	cancel_capture()
	hide()
	closed.emit()


func restore_defaults() -> void:
	cancel_capture()
	for action: String in CONTROLS:
		bind_keys(action, CONTROLS[action].slice(1))
		key_buttons[action].text = key_list(action)
	config.clear()
	sliders[0].value = 100
	sliders[1].value = 100
	apply_display(get_window())
	save()
	feedback.text = "Default settings restored."


func save() -> void:
	if config.save(FILE) != OK:
		feedback.text = "Could not save settings. Changes apply for this session."
