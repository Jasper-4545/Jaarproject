extends Node2D

const ENEMY = preload("res://scripts/enemy.gd")
const COIN := preload("res://assets/sprites/coin.png")
const AREAS := ["The Threshold", "Whispering Halls", "The Warden's Vault"]
const SPAWNS := [Vector2(85, 347), Vector2(995, 347), Vector2(1910, 347)]
const THORNS := [Rect2(380, 366, 66, 36), Rect2(1338, 366, 42, 36), Rect2(1490, 366, 178, 36)]
const FRAGMENTS := [Vector2(280, 261), Vector2(650, 197), Vector2(1179, 250), Vector2(1755, 255), Vector2(2699, 242)]
const GUIDE_POSITIONS := [
	Vector2(155, 350), Vector2(795, 350), Vector2(1080, 350),
	Vector2(1725, 350), Vector2(1955, 350),
]
const DASH_RELIC := Vector2(795, 322)
const EXIT := Vector2(2770, 350)
const PAPER := Color("#d8e7e5")
const TEAL := Color("#92e4d6")

@onready var hero = $Player
@onready var hud: CanvasLayer = $HUD
@onready var stats: Label = hud.get_node("%Stats")
@onready var area_label: Label = hud.get_node("%AreaLabel")
@onready var notice: Label = hud.get_node("%Notice")
@onready var boss_text: Label = hud.get_node("%BossName")
@onready var boss_bar: ProgressBar = hud.get_node("%BossHealth")
@onready var overlay: ColorRect = hud.get_node("%Overlay")
@onready var overlay_title: Label = hud.get_node("%Title")
@onready var overlay_copy: Label = hud.get_node("%Description")
@onready var start_button: Button = hud.get_node("%Play")
@onready var second_button: Button = hud.get_node("%MainMenu")
@onready var settings_button: Button = hud.get_node("%OpenSettings")
@onready var menu_content: VBoxContainer = hud.get_node("%Menu")
@onready var interface: Control = hud.get_node("%Interface")
@onready var preferences = hud.get_node("%Preferences")

var enemies: Array[Node2D] = []
var collected: Dictionary = {}
var checkpoint := 0
var zone := 0
var time := 0.0
var notice_time := 0.0
var base_camera_zoom: Vector2
var mode := "title"
var settings_from := "title"
var run_time := 0.0
var music := AudioStreamPlayer.new()
var effects := AudioStreamPlayer.new()


func _ready() -> void:
	base_camera_zoom = hero.camera.zoom
	hero.changed.connect(refresh_hud)
	hero.defeated.connect(on_defeat)
	add_enemy(Vector2(339, 350), 305, 364)
	add_enemy(Vector2(570, 350), 477, 669)
	add_enemy(Vector2(1221, 350), 1135, 1268)
	add_enemy(Vector2(1812, 350), 1730, 1850)
	add_enemy(Vector2(2420, 350), 2110, 2650, true)
	add_child(music)
	add_child(effects)
	var track: AudioStreamMP3 = preload("res://assets/music/time_for_adventure.mp3").duplicate()
	track.loop = true
	music.stream = track
	music.volume_db = -30.0
	effects.volume_db = -14.0
	start_button.pressed.connect(primary)
	settings_button.pressed.connect(open_settings)
	second_button.pressed.connect(func(): show_overlay("title"))
	preferences.closed.connect(func(): show_overlay(settings_from))
	refresh_hud()
	preferences.display_changed.connect(apply_display_scale)
	preferences.sound_changed.connect(apply_volume)
	apply_volume(preferences.music_level, preferences.effects_level)
	show_overlay("title")


func add_enemy(at: Vector2, left: float, right: float, boss: bool = false) -> void:
	var enemy := ENEMY.new()
	enemy.configure(hero, at, left, right, boss)
	enemy.process_mode = Node.PROCESS_MODE_PAUSABLE
	enemy.z_index = 3
	add_child(enemy)
	enemies.append(enemy)


func _process(delta: float) -> void:
	time += delta
	queue_redraw()
	if mode != "play":
		return
	run_time += delta
	notice_time = maxf(notice_time - delta, 0.0)
	notice.visible = notice_time > 0.0
	process_world()
	var guardian = enemies.back()
	boss_text.visible = guardian.active and guardian.is_alive() and zone == 2
	boss_bar.visible = boss_text.visible
	boss_bar.value = guardian.hp


func process_world() -> void:
	var at: Vector2 = hero.global_position
	if at.y > 465.0 or touched_thorns(at):
		hero.hurt(at, true)
		if hero.health > 0:
			hero.respawn(SPAWNS[checkpoint], false)
			announce("Returned to the last beacon.")
		return
	var next_zone := 2 if at.x >= 1880 else (1 if at.x >= 940 else 0)
	if zone != next_zone:
		zone = next_zone
		area_label.text = AREAS[zone]
		announce(AREAS[zone])
	if zone > checkpoint and hero.is_on_floor() and absf(at.x - SPAWNS[zone].x) < 95.0:
		checkpoint = zone
		announce("Beacon reached · Checkpoint set for this run")
	for index in range(FRAGMENTS.size()):
		if index not in collected and (at + Vector2(0, -20)).distance_to(FRAGMENTS[index]) < 28:
			collected[index] = true
			hero.fragments = collected.size()
			play_effect(preload("res://assets/sounds/coin.wav"))
			announce("Lantern shard found")
			refresh_hud()
	if Input.is_action_just_pressed("interact"):
		interact(at)


func touched_thorns(at: Vector2) -> bool:
	for patch in THORNS:
		if patch.has_point(at):
			return true
	return false


func interact(at: Vector2) -> void:
	if not hero.dash_unlocked and at.distance_to(DASH_RELIC) < 65:
		hero.dash_unlocked = true
		play_effect(preload("res://assets/sounds/power_up.wav"))
		announce("Ashstep unlocked · %s to dash" % preferences.key_list("dash"))
		refresh_hud()
	elif at.distance_to(EXIT) < 65:
		if enemies.back().is_alive():
			announce("The Ash Warden keeps the lantern sealed.")
		else:
			show_overlay("won")


func play_effect(stream: AudioStream) -> void:
	effects.stream = stream
	effects.play()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and mode in ["play", "pause"]:
		if mode == "pause":
			resume()
		else:
			show_overlay("pause")
		get_viewport().set_input_as_handled()


func on_defeat() -> void:
	show_overlay.call_deferred("dead")


func begin() -> void:
	collected.clear()
	hero.fragments = 0
	hero.dash_unlocked = false
	checkpoint = 0
	zone = 0
	run_time = 0.0
	for enemy in enemies:
		enemy.reset()
	hero.respawn(SPAWNS[0], true)
	area_label.text = AREAS[0]
	resume()
	announce("Follow the beacons east to find the lantern.")


func retry() -> void:
	for enemy in enemies:
		if enemy != enemies.back() or enemy.is_alive():
			enemy.reset()
	zone = checkpoint
	area_label.text = AREAS[zone]
	hero.respawn(SPAWNS[checkpoint], true)
	resume()


func resume() -> void:
	mode = "play"
	get_tree().paused = false
	overlay.hide()
	area_label.visible = true
	stats.visible = true
	if not music.playing:
		music.play()
	music.stream_paused = false


func announce(message: String) -> void:
	notice.text = message
	notice.visible = true
	notice_time = 3.1


func refresh_hud() -> void:
	stats.text = "%s    |    Focus %d/5    |    Shards %d/%d%s" % [
		"◆".repeat(hero.health) + "◇".repeat(hero.MAX_HEALTH - hero.health),
		hero.focus, hero.fragments, FRAGMENTS.size(), "    |    Ashstep" if hero.dash_unlocked else ""
	]


func show_overlay(next: String) -> void:
	mode = next
	get_tree().paused = true
	music.stream_paused = true
	overlay.show()
	menu_content.show()
	preferences.hide()
	settings_button.visible = next in ["title", "pause"]
	stats.hide()
	area_label.hide()
	notice.hide()
	boss_bar.hide()
	boss_text.hide()
	second_button.visible = next in ["pause", "dead"]
	match next:
		"title":
			overlay_title.text = "Beneath the Ashes"
			overlay_copy.text = "The last lantern has gone dark. Descend into the ruins, follow the beacons, and rekindle it."
			start_button.text = "Play"
		"pause":
			overlay_title.text = "Paused"
			overlay_copy.text = "%s  Jump   ·   %s  Attack\n%s  Ashstep   ·   %s  Heal   ·   %s  Interact" % [preferences.key_list("jump"), preferences.key_list("attack"), preferences.key_list("dash"), preferences.key_list("heal"), preferences.key_list("interact")]
			start_button.text = "Resume"
		"dead":
			overlay_title.text = "Your Light Went Out"
			overlay_copy.text = "Return to your last beacon. You keep your shards and Ashstep if you unlocked it."
			start_button.text = "Return to Beacon"
		"won":
			overlay_title.text = "The Light Returns"
			overlay_copy.text = "The Ash Warden has fallen. The lantern burns again.\n%d of %d shards found · %d min %02d sec" % [hero.fragments, FRAGMENTS.size(), int(run_time / 60), int(run_time) % 60]
			start_button.text = "Play Again"
	start_button.grab_focus()


func primary() -> void:
	match mode:
		"pause": resume()
		"dead": retry()
		_: begin()


func apply_display_scale(canvas_size: Vector2i, render_size: Vector2i) -> void:
	interface.size = canvas_size
	hud.scale = Vector2(render_size) / Vector2(canvas_size)
	hero.camera.zoom = base_camera_zoom * hud.scale


func open_settings() -> void:
	settings_from = mode
	mode = "settings"
	menu_content.hide()
	preferences.show()
	preferences.back.grab_focus()


func apply_volume(music_level: float, effects_level: float) -> void:
	music.volume_db = -30.0 + linear_to_db(maxf(music_level, 0.0001))
	effects.volume_db = -14.0 + linear_to_db(maxf(effects_level, 0.0001))
	hero.speaker.volume_db = -13.0 + linear_to_db(maxf(effects_level, 0.0001))


func guide_text(index: int) -> String:
	match index:
		0: return "%s  Jump  ·  %s  Attack" % [preferences.key_list("jump"), preferences.key_list("attack")]
		1: return "%s  ·  Touch the relic" % preferences.key_list("interact")
		2: return "%s  ·  Dash in midair" % preferences.key_list("dash")
		3: return "Stand still and hold %s to heal" % preferences.key_list("heal")
		_: return "Watch for the Warden's windup"


func _draw() -> void:
	for point in SPAWNS:
		draw_lamp(point + Vector2(0, -41), TEAL)
	for guide in range(GUIDE_POSITIONS.size()):
		draw_string(ThemeDB.fallback_font, GUIDE_POSITIONS[guide] + Vector2(-62, -55), guide_text(guide), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, PAPER)
	for index in range(FRAGMENTS.size()):
		if index not in collected:
			var p: Vector2 = FRAGMENTS[index] + Vector2(0, roundf(sin(time * 3.0 + index) * 3.0))
			draw_circle(p, 12, Color("#bded831c"))
			draw_texture_rect_region(COIN, Rect2(p - Vector2(12, 12), Vector2(24, 24)), Rect2((int(time * 9) % 12) * 16, 0, 16, 16), Color("#c5ffb8"))
	if not hero.dash_unlocked:
		draw_lamp(DASH_RELIC, Color("#9cecea"))
		draw_arc(DASH_RELIC, 13 + sin(time * 4) * 2, 0, TAU, 28, TEAL, 1.5)
	draw_arch(EXIT, 58, 83, Color("#58777c"), 8)
	draw_lamp(EXIT + Vector2(0, -35), Color("#f9c184") if not enemies.is_empty() and enemies.back().is_alive() else TEAL)


func draw_arch(base: Vector2, width: float, height: float, shade: Color, thickness: float) -> void:
	var y := base.y - height + width * 0.5
	var center := Vector2(base.x + width * 0.5, y)
	draw_arc(center, width * 0.5, PI, TAU, 14, shade, thickness)
	draw_line(Vector2(base.x, y), base, shade, thickness)
	draw_line(Vector2(base.x + width, y), base + Vector2(width, 0), shade, thickness)


func draw_lamp(p: Vector2, color: Color) -> void:
	for ring in range(6, 0, -1):
		draw_circle(p, ring * 6.0, Color(color.r, color.g, color.b, 0.025))
	draw_line(p, p + Vector2(0, 40), Color("#405760"), 2)
	draw_rect(Rect2(p - Vector2(4, 6), Vector2(8, 11)), color)
	draw_rect(Rect2(p - Vector2(2, 4), Vector2(4, 6)), Color("#edffed"))
