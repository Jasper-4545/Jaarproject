# Beneath the Ashes

The last lantern beneath the ruins has gone dark. Follow the beacons, unlock Ashstep, and defeat the Ash Warden to rekindle it.

Extract the ZIP, import `project.godot` into Godot 4.7.2, and press F5.

| Key | Action |
| --- | --- |
| A/Q and D, or Left and Right | Move |
| Space | Jump. Release early for a shorter jump. |
| J or X | Attack. Hold an up or down key to aim your swing. |
| K or Shift | Use Ashstep once unlocked. One dash per jump. |
| F | Stand still on the ground and hold to heal. Three Focus restore one point of health. |
| E | Touch the relic or relight the lantern. |
| Esc | Pause or resume. |

Each successful hit grants one Focus. Lantern shards are optional. Falling between platforms costs one point of health. Beacons mark checkpoints for the current run. After defeat, you can return to the last beacon with full health. Starting a new game resets your progress through the ruins.

## Settings

Open **Settings** from the main menu or pause menu. Select an action and press a new key. Press Esc to cancel a key change. Music and sound effects have separate sliders. **Resolution** lists the 16:9 options that fit your screen. It changes the render resolution and, in a standalone game window, the window size. To open a standalone window, switch off **Embed Game on Next Play** in Godot's **Game** tab. Your preferences are saved on this device. Select **Restore Defaults** to reset them.

## Project structure

- `scenes/game.tscn` contains the world, player and scrolling background. Select **Background** in the scene tree and change **Scroll Scale** in the Inspector to adjust how quickly it follows the camera.
- `scenes/platforms.tscn` contains the platform collision shapes. The foreground sprite is the matching level artwork.
- `scenes/hud.tscn` contains the menus and on-screen interface. Edit text and layout in the Godot scene editor.
- `scripts/game.gd` controls the run, checkpoints and ending. `player.gd` handles movement and combat, `enemy.gd` handles enemy behavior, and `settings.gd` manages preferences.

## Credits

- One Man Army. (2017, January 19). *Plagueking [48x48]* [Pixel art, CC0]. OpenGameArt.org. The sprite was adapted into 24 animation frames for this project. https://opengameart.org/content/plagueking-48x48
- The hero, slimes, coins, tiles, fonts, music, and sounds came with the original school project. Their original creators and licenses still need to be confirmed before public distribution.
